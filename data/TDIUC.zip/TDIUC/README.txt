%%%%%%%%%%%%%%%% SETUP %%%%%%%%%%%%%%%%

1. Run setup.py with appropriate arguments. Run "python setup.py -h" to find the details about the
required arguments

	1.1 To automatically download and setup all required files

		1.1.1 Run: "python setup.py --download Y"
	 
	1.2 Alternately, To skip download (download manually),

		1.2.1 Download Version 1.2 of Visual Genome images and image meta data

		1.2.2 Download train2014 and val2014 images from MS-COCO into a directory named 'Images'

		1.2.3 Run: "python setup.py --download N --genome_src [GENOME_SOURCE_DIR]" where,
		GENOME_SOURCE_DIR = Path to directory containing Visual Genome images (with directories
		VG_100K, VG_100K_2) and metadata image_data.json

2. After completing either 1.1 or 1.2, "Images" directory will contain all the required images for
TDIUC under train2014 and val2014 directories

3. You may now delete "downloads" folder to save space

================ IMPORTANT NOTE: ================

The images, annotation and question json filenames are kept unchanged from the VQA dataset since
many open-source VQA models (including the models used in the paper) are designed for that specific
filename pattern. This saves you a lot of work if you want to simply retrain your model on TDIUC
that is previously written for the VQA dataset.

However, keep in mind that despite the naming, the images, questions and annotations come from
different sources as described in the paper.


%%%%%%%%%%%%% LIST OF FILES %%%%%%%%%%%%%


setup.py: Contains script to setup TDIUC

evaluate.py: Contains script to calculate MPT and N-MPT accuracy as well as individual accuracies
for each question-type, expects a .json file identical to the one needed for VQA evaluation servers

sample_answerkey.csv: Shows a sample answerkey format that is expected by evaluate.py script. For
TDIUC, you can simply use this one, but if you wish to use your own , please ensure that it follows
similar format.

train_val_split_genome.pickle:  Contains training and validation image ids for visual genome
annotations. Needed by setup.py

================== ./Annotations ==================

Annotations that follows similar naming and organization pattern compared to the VQA dataset
(http://visualqa.org/download.html) mscoco_train2014_annotations.json is to be used as training and
mscoco_val2014_annotations.json is intended to be validation/test split. Additional question_type'
field is present to denote the type of question.

============ ./Questions ============

Questions that follows similar naming and organization pattern compared to the VQA dataset
(http://visualqa.org/download.html) OpenEnded_mscoco_train2014_questions.json is to be used as
training and OpenEnded_mscoco_val2014_questions.json is intended to be validation/test split.


============ ./Extra ============

Contains the images that were manually uploaded by annotators. train2014 contains images for the
training split and val2014 contains images for the validation/test split



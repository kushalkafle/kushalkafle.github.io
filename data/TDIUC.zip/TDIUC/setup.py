import json
import cPickle
import sys
import argparse
import os
import errno
import requests
import shutil
import zipfile

def make_iid(im_id, image_src):
    """ Make a unique image id
    Inputs:
        im_id = Raw image id for manual or genome images
        image_src = 'manual' or 'genome'
    Returns:
        image_id: Integer with 8 digits, where first digit represents the source of image,
            8 = 'manual' and 9 = 'genome' and the rest of the digits are original image_ids
            right justified (padded with zeros) to a lenght of seven.            
    """ 
    if image_src == 'genome':
        src_id = 9
    elif image_src == 'manual':
        src_id = 8
    image_id = str(src_id)+str(im_id).rjust(7,'0')
    return image_id

def create_dir(dir_path, err_if_exist=False):
    try:
        os.makedirs(dir_path)
    except OSError as e:
        if e.errno == errno.EEXIST:
            if err_if_exist:
                raise OSError('Directory Already Exists')
        else:
            raise OSError('Error creating Directory %s'%dir_path)
        
def copy_genome(source_folder, target_folder):
    """ Rename and copy Visual Genome images to create similar naming pattern as MS-COCO
    Inputs:
        source_folder: Source of Visual Genome images and metadata
        target_folder: Where to copy the files, normally where MS-COCO images are
    Returns:
        None
    """
    
    genome_image_data = json.load(open(os.path.join(source_folder,'image_data.json')))
    with open('train_val_split_genome.pickle') as f:
        train_ids,val_ids = cPickle.load(f)        
    for idx,im in enumerate(genome_image_data):
        if idx%100 == 0:
            sys.stdout.write('\rProcessed %s of %s Visual Genome images'%(
                    str(idx),str(len(genome_image_data))))
            sys.stdout.flush()
        if im['coco_id'] is None:
            src_filename = '/'.join(im['url'].split('/')[-2:])
            src_filename = os.path.join(source_folder, src_filename)
            if im['image_id'] in val_ids:
                fname = 'val2014/COCO_val2014_'+make_iid(im['image_id'], 'genome').rjust(12,'0')+'.jpg'
                target_filename = os.path.join(target_folder,fname)
            else:
                fname = 'train2014/COCO_train2014_'+ make_iid(im['image_id'], 'genome').rjust(12,'0')+'.jpg'
                target_filename = os.path.join(target_folder,fname)
            shutil.copy(src_filename, target_filename)

def copy_manual(manual_img_dir, target_dir):
    for folder in ['train2014', 'val2014']:
        img_dir = os.path.join(manual_img_dir, folder)
        for item in os.listdir(img_dir):
            s = os.path.join(img_dir, item)
            d = os.path.join(target_dir, folder, item)
            shutil.copy(s, d)
    
def download_extract(dlink, target):
    create_dir(target)
    """Download and unpack visual genome images and metadata"""
    fname = dlink.split('/')[-1]
    print 'Downloading %s ...'%dlink
    chunk_sz = 1024*1024 # 1MB chunks
    file_stream = requests.get(dlink, stream=True)
    fsize = int(file_stream.headers['Content-length']) / (chunk_sz)
    disk_file = open(os.path.join(target,fname), "wb")
    downloaded = 0
    for chunk in file_stream.iter_content(chunk_size= chunk_sz):
        if chunk:
            sys.stdout.write('\rDownloading %s, Downloaded %d of %d MBs'%(
                    fname,downloaded,fsize))
            sys.stdout.flush()
            disk_file.write(chunk)
            downloaded+=1
    disk_file.close()
    print '\nExtracting %s ...'%dlink
    with zipfile.ZipFile(os.path.join(target,fname)) as zf:
        zf.extractall(target)

def main():
    parser = argparse.ArgumentParser()
    req = parser.add_argument_group('Required Arguments')

    req.add_argument('--download', required=True,
                        help='Y to download necessary files or N to skip download \
                        (for manual download). Additional arguments are required if download is skipped.')
    
    req_no_download = parser.add_argument_group('Required Arguments if Download is False')
    
    req_no_download.add_argument('--genome_src', required=False,
                    help='Source directory for Visual Genome images and metadata.\
                    Should contain the directories VG_100K and VG_100K_2 and the \
                    Image metadata file image_data.json')
    req_no_download.add_argument('--target_dir', required=False, default='Images',
                    help='Target Direcotory where manual and Visual Genome Images are copied,\
                          Expected to train2014 and val2014 directories with MS-COCO images.')
    args = parser.parse_args()
    
    if args.download == 'Y':
               
        dlinks_coco = ['http://msvocds.blob.core.windows.net/coco2014/val2014.zip',
                       'http://msvocds.blob.core.windows.net/coco2014/train2014.zip']
        for dlink in dlinks_coco[1:]:
            download_extract(dlink,target='Images')
        
        dlinks_genome = ['http://visualgenome.org/static/data/dataset/image_data.json.zip',
                         'https://cs.stanford.edu/people/rak248/VG_100K_2/images.zip',
                         'https://cs.stanford.edu/people/rak248/VG_100K_2/images2.zip',]
        for dlink in dlinks_genome:
            download_extract(dlink,target='downloads')
        
        genome_dir = 'downloads'
        target_dir = 'Images'

    elif args.download == 'N':
        if args.target_dir is None or args.genome_src is None:
            raise ValueError('--genome_src and --target_dir are required when --download is N.\
                             Type "python setup.py -h" for usage help')
        genome_dir = args.genome_src
        target_dir = args.target_dir
    else:
        raise ValueError('Unknown option for --download, Expected Y or N')
    
    create_dir('%s/train2014'%target_dir)
    create_dir('%s/val2014'%target_dir)
    manual_img_dir = 'Extra'
    print 'Copying manually uploaded images'
    copy_manual(manual_img_dir,target_dir)
    print 'Done copying manual images'
    print 'Copying Visual Genome images'
    copy_genome(genome_dir,target_dir)
    print 'Done copying Visual Genome images'
    print 'Done.'
    
if __name__ == "__main__":
    main()